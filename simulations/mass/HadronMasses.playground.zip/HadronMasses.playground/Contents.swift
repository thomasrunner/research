//
//  HadronMasses.swift
//
//  Created by Thomas Lock on Jun 2 2025
//  Based on Paper > https://zenodo.org/records/15596490


import Foundation

let hadrons: [Hadron] = [

    //Quarks
    Hadron(name: "u",       mass: 2.2,  spin: 0.5, isospin: 0.5,  isospin3: 0.5,   quarks: ["u"], state: 1),
    Hadron(name: "d",       mass: 5.30000, spin: 0.5, isospin: 0.5,  isospin3: -0.5,   quarks: ["d"], state: 1),
    Hadron(name: "s",       mass: 184.0025, spin: 0.5, isospin: 0.0,  isospin3: 0.0,  quarks: ["s"], state: 1),
    Hadron(name: "c",        mass: 1541.60615,   spin: 0.5, isospin: 0.0,  isospin3: 0.0,   quarks: ["c"], state: 1),
    Hadron(name: "b",        mass: 4696.36393,   spin: 0.5, isospin: 0.0,  isospin3: 0.5,  quarks: ["b"], state: 1),

    //Mesons
    Hadron(name: "Pi0",       mass: 134.9766,  spin: 0.0, isospin: 1.0,  isospin3: 0.0,   quarks: ["u", "d"], state: 1),
    Hadron(name: "Pi+",       mass: 139.57039, spin: 0.0, isospin: 1.0,  isospin3: 1.0,   quarks: ["u", "d"], state: 1),
    Hadron(name: "Pi-",       mass: 139.57039, spin: 0.0, isospin: 1.0,  isospin3: -1.0,  quarks: ["u", "d"], state: 1),
    Hadron(name: "K+",        mass: 493.677,   spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["u", "s"], state: 1),
    Hadron(name: "K-",        mass: 493.677,   spin: 0.0, isospin: 0.5,  isospin3: -0.5,  quarks: ["u", "s"], state: 1),
    Hadron(name: "K0",        mass: 497.611,   spin: 0.0, isospin: 0.5,  isospin3: -0.5,  quarks: ["d", "s"], state: 1),
    Hadron(name: "K̄0",       mass: 497.611,   spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["d", "s"], state: 1),
    Hadron(name: "K0_S",      mass: 497.611,   spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["d", "s"], state: 1),
    Hadron(name: "K0_L",      mass: 497.611,   spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["d", "s"], state: 1),

    Hadron(name: "D0",        mass: 1864.841,  spin: 0.0, isospin: 0.5,  isospin3: -0.5,  quarks: ["c", "u"], state: 1),
    Hadron(name: "D̄0",       mass: 1864.841,  spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["c", "u"], state: 1),
    Hadron(name: "D+",        mass: 1869.65,   spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["c", "d"], state: 1),
    Hadron(name: "D-",        mass: 1869.65,   spin: 0.0, isospin: 0.5,  isospin3: -0.5,  quarks: ["c", "d"], state: 1),
    Hadron(name: "Ds+",       mass: 1968.34,   spin: 0.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["c", "s"], state: 1),
    Hadron(name: "Ds-",       mass: 1968.34,   spin: 0.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["c", "s"], state: 1),

    Hadron(name: "B+",        mass: 5279.1,    spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["b", "u"], state: 1),
    Hadron(name: "B-",        mass: 5279.1,    spin: 0.0, isospin: 0.5,  isospin3: -0.5,  quarks: ["b", "u"], state: 1),
    Hadron(name: "B0",        mass: 5279.1,    spin: 0.0, isospin: 0.5,  isospin3: -0.5,  quarks: ["b", "d"], state: 1),
    Hadron(name: "B̄0",       mass: 5279.1,    spin: 0.0, isospin: 0.5,  isospin3: 0.5,   quarks: ["b", "d"], state: 1),
    Hadron(name: "Bs0",       mass: 5366.88,   spin: 0.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "s"], state: 1),
    Hadron(name: "Bs̄0",      mass: 5366.88,   spin: 0.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "s"], state: 1),
    Hadron(name: "Bc+",       mass: 6274.9,    spin: 0.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "c"], state: 1),
    Hadron(name: "Bc-",       mass: 6274.9,    spin: 0.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "c"], state: 1),


    Hadron(name: "J/Psi",     mass: 3096.9,    spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["c", "c"], state: 1),
    Hadron(name: "Psi(2S)",   mass: 3686.1,    spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["c", "c"], state: 2),
    Hadron(name: "Rho+",      mass: 775.11,    spin: 1.0, isospin: 1.0,  isospin3: 1.0,   quarks: ["u", "d"], state: 1),
    Hadron(name: "Rho-",      mass: 775.11,    spin: 1.0, isospin: 1.0,  isospin3: -1.0,  quarks: ["u", "d"], state: 1),
    Hadron(name: "Upsilon(1S)", mass: 9460.3,  spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "b"], state: 1),
    Hadron(name: "Upsilon(2S)", mass: 10023.26, spin: 1.0, isospin: 0.0, isospin3: 0.0,   quarks: ["b", "b"], state: 2),
    Hadron(name: "Upsilon(3S)", mass: 10355.2, spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "b"], state: 3),
    Hadron(name: "Upsilon(4S)", mass: 10579.4, spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "b"], state: 4),
    Hadron(name: "Upsilon(5S)", mass: 10885.0, spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "b"], state: 5),
    Hadron(name: "Upsilon(6S)", mass: 11000.0, spin: 1.0, isospin: 0.0,  isospin3: 0.0,   quarks: ["b", "b"], state: 6),

    //Baryons
    Hadron(name: "Proton",       mass: 938.272089, spin: 0.5, isospin: 0.5, isospin3: 0.5,  quarks: ["u", "u", "d"], state: 1),
    Hadron(name: "Neutron",      mass: 939.565421, spin: 0.5, isospin: 0.5, isospin3: -0.5, quarks: ["u", "d", "d"], state: 1),

    Hadron(name: "Lambda0",      mass: 1115.683,   spin: 0.5, isospin: 0.0, isospin3: 0.0,  quarks: ["u", "d", "s"], state: 1),
    Hadron(name: "Sigma+",       mass: 1189.370,   spin: 0.5, isospin: 1.0, isospin3: 1.0,  quarks: ["u", "u", "s"], state: 1),
    Hadron(name: "Sigma0",       mass: 1192.642,   spin: 0.5, isospin: 1.0, isospin3: 0.0,  quarks: ["u", "d", "s"], state: 1),
    Hadron(name: "Sigma−",       mass: 1197.449,   spin: 0.5, isospin: 1.0, isospin3: -1.0, quarks: ["d", "d", "s"], state: 1),
    Hadron(name: "Delta++",      mass: 1232.000,   spin: 1.5, isospin: 1.5, isospin3: 1.5,  quarks: ["u", "u", "u"], state: 1),
    Hadron(name: "Delta+",       mass: 1232.000,   spin: 1.5, isospin: 1.5, isospin3: 0.5,  quarks: ["u", "u", "d"], state: 1),
    Hadron(name: "Delta0",       mass: 1232.000,   spin: 1.5, isospin: 1.5, isospin3: -0.5, quarks: ["u", "d", "d"], state: 1),
    Hadron(name: "Delta−",       mass: 1232.000,   spin: 1.5, isospin: 1.5, isospin3: -1.5, quarks: ["d", "d", "d"], state: 1),

    Hadron(name: "Xi0",          mass: 1314.860,   spin: 0.5, isospin: 0.5, isospin3: 0.5,  quarks: ["u", "s", "s"], state: 1),
    Hadron(name: "Xi−",          mass: 1321.710,   spin: 0.5, isospin: 0.5, isospin3: -0.5, quarks: ["d", "s", "s"], state: 1),
    Hadron(name: "Omega−",       mass: 1672.450,   spin: 1.5, isospin: 0.0, isospin3: 0.0,  quarks: ["s", "s", "s"], state: 1),

    Hadron(name: "Lambda+c",     mass: 2286.460,   spin: 0.5, isospin: 0.0, isospin3: 0.0,  quarks: ["u", "d", "c"], state: 1),//High
    Hadron(name: "Sigma++c",     mass: 2453.970,   spin: 0.5, isospin: 1.0, isospin3: 1.0,  quarks: ["u", "u", "c"], state: 1),
    Hadron(name: "Sigma+c",      mass: 2452.900,   spin: 0.5, isospin: 1.0, isospin3: 0.0,  quarks: ["u", "d", "c"], state: 1),
    Hadron(name: "Sigma0c",      mass: 2453.750,   spin: 0.5, isospin: 1.0, isospin3: -1.0, quarks: ["d", "d", "c"], state: 1),
    Hadron(name: "Xi0c",         mass: 2470.850,   spin: 0.5, isospin: 0.5, isospin3: -0.5, quarks: ["d", "s", "c"], state: 1),//High
    Hadron(name: "Xi+c",         mass: 2468.000,   spin: 0.5, isospin: 0.5, isospin3: 0.5,  quarks: ["u", "s", "c"], state: 1),//High
    Hadron(name: "Omega0c",      mass: 2695.200,   spin: 0.5, isospin: 0.0, isospin3: 0.0,  quarks: ["s", "s", "c"], state: 1),

    Hadron(name: "Lambda0b",     mass: 5619.600,   spin: 0.5, isospin: 0.0, isospin3: 0.0,  quarks: ["u", "d", "b"], state: 1),
    Hadron(name: "Xi0b",         mass: 5787.800,   spin: 0.5, isospin: 0.5, isospin3: 0.5,  quarks: ["u", "s", "b"], state: 1),
    Hadron(name: "Xi−b",         mass: 5794.400,   spin: 0.5, isospin: 0.5, isospin3: -0.5, quarks: ["d", "s", "b"], state: 1),
    Hadron(name: "Omega−b",      mass: 6045.100,   spin: 0.5, isospin: 0.0, isospin3: 0.0,  quarks: ["s", "s", "b"], state: 1),

]

import Foundation

struct Hadron {
    let name: String
    let mass: Double
    let spin: Double
    let isospin: Double
    let isospin3: Double
    let quarks: [String]
    let state: Int
}

// --- Constants ---
let E_quark = 2.2
var E_base = 114.883111
var E_spin_coupling = 251.39
let E_isospin_coupling = 16.0

let E_state = -104.546
let E_state_G2 = E_state * -pow(100,1/3)
let E_state_G3 = E_state * -2.0 

let E_charm_coupling = 66.45
let E_strange_coupling = 9.6

var sigma =  0.262

let transitionL1: [String: Double] = [
    "u→d": 3.1,
    "d→s": 357.405,
    "s→c": 1371.35,
    "c→b": 3403.1
]

let generation: [String: Double] = [
    "u": 1, "d": 1,
    "s": 2, "c": 2,
    "b": 3
]

// Return 1 if quark is light (u, d), else 2
func level(of quark: String) -> Int {
    return ["u", "d"].contains(quark) ? 1 : 2
}

// Returns transition cost from → to using L1 or L2 rules
func transitionPath(from: String, to: String, isL1: Bool) -> Double {
    //Meson
    let path = ["u", "d", "s", "c", "b"]
    guard let start = path.firstIndex(of: from),
          let end = path.firstIndex(of: to),
          start != end else { return 0.0 }

    let stepPath: [String] = start < end
        ? Array(path[start...end])
        : Array(path[end...start].reversed())

    var cost = 0.0
    for (a, b) in zip(stepPath, stepPath.dropFirst()) {
        let key = "\(a)→\(b)"
        let base = transitionL1[key] ?? 0.0
        if isL1 {
            cost += base
        } else {
            switch (a, b) {
            case ("u", "d"): cost += base
            case ("d", "s"): cost += base / 3.0
            case ("s", "c"): cost += base * 2.0 / 3.0
            case ("c", "b"): cost += base
            default: break
            }
        }
    }

    return cost
}

func deltaEbase(for quarks: [String]) -> Double {
    //Baryon
    var total = 0.0

    if quarks.count == 2 {
        let (q1i, q2i) = ("u","u")
        let (q1f, q2f) = (quarks[0],quarks[1])

        let step1 = transitionPath(from: q1i, to: q1f, isL1: level(of: q2i) == 1)
        let step2 = transitionPath(from: q2i, to: q2f, isL1: level(of: q1f) == 1)
        return step1 + step2

    } else {
        for q in quarks {
            switch q {
            case "u":
                total += 0
            case "d":
                total += transitionL1["u→d"]!
            case "s":
                total += transitionL1["u→d"]! + (transitionL1["d→s"]! / 2)
            case "c":
                total += transitionL1["u→d"]! + (6 * transitionL1["d→s"]! / 13) + transitionL1["s→c"]!
            case "b":
                total += transitionL1["u→d"]! + (transitionL1["d→s"]!) + 38 * transitionL1["s→c"]! / 56 + transitionL1["c→b"]!
            default:
                total += 0
            }
        }
    }
    return total
}

func stateEnergy(state: Int, spin: Double, G: Double, Q: Double) -> Double {
    if spin > 0 && Q < 3 {
        if G == 2 {
            if state == 1 {
                return E_state
            } else if state == 2 {
                return E_state_G2
            }
        } else if G == 3 {
            if state == 1 {
                return E_state * 21/5
            } else if state == 2 {
                return E_state_G2 / 4
            } else {
                return E_state_G3 * Double(state - 1) - E_state * Double(state) / 9
            }
        }
    }
    return 0
}

func nQuarks(for quarks: [String]) -> [Double] {
    //Hadron
    var total = 0.0

    //Qu, Qd, Qs, Qc, Qb, Qt
    var Q: [Double] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    for q in quarks {
        switch q {
        case "u":
            Q[0] += 1.0
        case "d":
            Q[1] += 1.0
        case "s":
            Q[2] += 1.0
        case "c":
            Q[3] += 1.0
        case "b":
            Q[4] += 1.0
        case "t":
            Q[5] += 1.0
        default:
            total += 0
        }
    }

    return Q
}

func gate(_ condition: Bool) -> Double { condition ? 1.0 : 0.0 }

// Full mass prediction function
func predictedMass(hadron: Hadron) -> Double {
    let q1 = hadron.quarks[0]
    let q2 = hadron.quarks.count > 1 ? hadron.quarks[1] : "u"
    let q3 = hadron.quarks.count > 2 ? hadron.quarks[2] : "u"
    let G1 = generation[q1] ?? 1.0
    let G2 = generation[q2] ?? 1.0
    let G3 = generation[q3] ?? 1.0
    let Q: Double = Double(hadron.quarks.count)
    var G: Double = Double(max(G1, G2))

    let Qu = hadron.quarks.contains("u") ? 1.0 : 0.0
    let Qd = hadron.quarks.contains("d") ? 1.0 : 0.0
    let Qs = hadron.quarks.contains("s") ? 1.0 : 0.0
    let Qc = hadron.quarks.contains("c") ? 1.0 : 0.0
    let Qb = hadron.quarks.contains("b") ? 1.0 : 0.0
    let Tri = hadron.quarks.count == 3 ? 1.0 : 0.0

    let NQ = nQuarks(for: hadron.quarks)

    let Nu = NQ[0]
    let Nd = NQ[1]
    let Ns = NQ[2]

    G = max(G, Double(G3))

    if Q == 1 {

        let ΔE = deltaEbase(for: hadron.quarks)

        return E_quark + ΔE

    } else {

        let a = (7/2) * (pow(Q,2.0) - Q)/2.0 - (5/2)
        let E_base_a = E_base * a

        let isospin_coupling = E_isospin_coupling * hadron.isospin * G * (Q - 1.0) + abs(Tri - 1.0) * pow(2.0 * E_isospin_coupling / 7.0, gate(hadron.isospin == 1.0 && abs(hadron.isospin3) == 1.0) * G1)

        let spin_coupling = E_spin_coupling * pow((abs(Q - 4.0)), 4.0 / 3.0)  * (hadron.spin - ((Q - 2)/2)) * pow(5.0 - G, abs(2.0 - Q)) / (pow(4.0, abs(2 - Q)) * pow(G, abs(Q - 3.0)))

        let state_excitation = stateEnergy(state: hadron.state, spin: hadron.spin, G: Double(G), Q: Q)

        let flavor_coupling = pow(E_strange_coupling * G, Qs * Tri) * pow(-1, Qc) - pow(E_strange_coupling * 9, Qb * Tri * Qs * (Qu + Qd)) - Qc * Tri * (E_charm_coupling + pow(E_charm_coupling * 2.0, Qs) - pow(E_charm_coupling, gate(hadron.isospin == 0)) + pow(E_charm_coupling * 2.7, gate(hadron.isospin == 0) * Qd))

        let ΔE = deltaEbase(for: hadron.quarks)

        return E_base_a + ΔE + isospin_coupling  + state_excitation + spin_coupling + flavor_coupling

    }
}

// --- Run Predictions ---
var totalError = 0.0

for hadron in hadrons {

    let pred = predictedMass(hadron: hadron)
    let err = ((pred - hadron.mass) / hadron.mass) * 100.0
    print("\(hadron.name.padding(toLength: 16, withPad: " ", startingAt: 0)) | Obs: \(String(format: "%9.5f", hadron.mass)) | Pred: \(String(format: "%9.5f", pred)) | Δ%: \(String(format: "%+6.5f", err))")
    totalError += abs(err)
}

print(String(format: "Average Δ%% error: %.5f%%", totalError / Double(hadrons.count)))

//Atomic Masses
struct Isotope {
    let name: String
    let Z: Int       // protons
    let N: Int       // neutrons
    let massObs: Double // MeV
    let halfLife: Double // seconds; use Double.infinity for stable
}

let M_p = 938.27209    // proton mass
let M_n = 941.91209    // neutron mass
let m_e = 0.5109989461 // Electron mass

let isotopes: [Isotope] = [
    Isotope(name: "Protium",       Z: 1,  N: 0,   massObs: 938.272,     halfLife: .infinity),
    Isotope(name: "Deuterium",     Z: 1,  N: 1,   massObs: 1875.612,    halfLife: .infinity),
    Isotope(name: "Tritium",       Z: 1,  N: 2,   massObs: 2808.921,    halfLife: 3.888e8),
    Isotope(name: "Helium-3",      Z: 2,  N: 1,   massObs: 2808.391,    halfLife: .infinity),
    Isotope(name: "Helium-4",      Z: 2,  N: 2,   massObs: 3727.379,    halfLife: .infinity),
    Isotope(name: "Lithium-6",     Z: 3,  N: 3,   massObs: 5601.519,    halfLife: .infinity),
    Isotope(name: "Lithium-7",     Z: 3,  N: 4,   massObs: 6533.832,    halfLife: .infinity),
    Isotope(name: "Beryllium-9",   Z: 4,  N: 5,   massObs: 8394.795,    halfLife: .infinity),
    Isotope(name: "Boron-10",      Z: 5,  N: 5,   massObs: 9310.194,    halfLife: .infinity),
    Isotope(name: "Boron-11",      Z: 5,  N: 6,   massObs: 10254.545,   halfLife: .infinity),
    Isotope(name: "Carbon-12",     Z: 6,  N: 6,   massObs: 11177.928,   halfLife: .infinity),
    Isotope(name: "Carbon-14",     Z: 6,  N: 8,   massObs: 13044.570,   halfLife: 1.8e11),
    Isotope(name: "Nitrogen-14",   Z: 7,  N: 7,   massObs: 13043.780,   halfLife: .infinity),
    Isotope(name: "Oxygen-16",     Z: 8,  N: 8,   massObs: 14900.383,   halfLife: .infinity),
    Isotope(name: "Oxygen-18",     Z: 8,  N:10,   massObs: 16791.228,   halfLife: .infinity),
    Isotope(name: "Iron-56",       Z: 26, N: 30,  massObs: 52048.736,   halfLife: .infinity),
    Isotope(name: "Nickel-62",     Z: 28, N: 34,  massObs: 57674.0,     halfLife: .infinity),
    Isotope(name: "Lead-206",      Z: 82, N:124,  massObs: 191902.4,    halfLife: .infinity),
    Isotope(name: "Lead-208",      Z: 82, N:126,  massObs: 193681.3,    halfLife: .infinity),
    Isotope(name: "Uranium-235",   Z: 92, N:143,  massObs: 218876.7,    halfLife: 2.22e16),
    Isotope(name: "Uranium-238",   Z: 92, N:146,  massObs: 221695.8,    halfLife: 1.41e17),
    Isotope(name: "Plutonium-239", Z: 94, N:145,  massObs: 223888.0,    halfLife: 7.6e11)
]


var isotopeError = 0.0
for iso in isotopes {
    let Z = Double(iso.Z)
    let N = Double(iso.N)
    let A = Z + N

    // Base mass prediction: sum of proton, neutron, and electron masses
    let baseMass = Z * M_p + N * M_n + Z * m_e

    // Apply decay correction factor kappa(A)
    let kappa = 0.9995 - 0.00621 * pow(A / 239.0, 0.0154) * N/Z

    let predicted = baseMass * kappa
    let error = ((predicted - iso.massObs) / iso.massObs) * 100.0

    print("\(iso.name.padding(toLength: 16, withPad: " ", startingAt: 0)) | Obs: \(String(format: "%9.5f", iso.massObs)) | Pred: \(String(format: "%9.5f", predicted)) | Δ%%: \(String(format: "%+9.5f", error))")

    totalError += abs(error)
    isotopeError += abs(error)
}
print(String(format: "Atomic Isotope Δ%% error: %.5f%%", isotopeError / Double(isotopes.count)))
print(String(format: "Total Hadron + Atomic Δ%% error: %.5f%%", totalError / Double(isotopes.count + hadrons.count)))


