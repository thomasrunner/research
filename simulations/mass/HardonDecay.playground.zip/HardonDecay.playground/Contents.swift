//
//  HadronDecay.swift
//
//  Created by Thomas Lock on Jun 2 2025
//  Based on Paper > https://zenodo.org/records/15596490


import SwiftUI
import Charts
import PlaygroundSupport
import Foundation

let hadrons: [Hadron] = [
//    Hadron(name: "Proton",       quarks: ["u", "u", "d"], spin: 0.5, mass: 938.272089,  isospin: 0.5, isospin3: 0.5, state: 1, decayTime: 0.0, cp: 0, superposition: 0, charge: 1.0),

    Hadron(name: "Neutron",      quarks: ["u", "d", "d"], spin: 0.5, mass: 939.565421,  isospin: 0.5, isospin3: -0.5, state: 1, decayTime: 880, cp: 0, superposition: 0, charge: 0.0),

    Hadron(name: "K0",        quarks: ["d", "s"], spin: 0.0, mass: 497.611,   isospin: 0.5,  isospin3: -0.5, state: 1, decayTime: 5.116e-8,   cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "K̄0",       quarks: ["d", "s"], spin: 0.0, mass: 497.611,   isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 5.116e-8,   cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "K0_L",      quarks: ["d", "s"], spin: 0.0, mass: 497.611,   isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 5.116e-8,   cp: 0, superposition: 0, charge:  0.0),
    
    Hadron(name: "Pi+",       quarks: ["u", "d"], spin: 0.0, mass: 139.57039, isospin: 1.0,  isospin3:  1.0, state: 1, decayTime: 2.6033e-8,  cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "Pi−",       quarks: ["u", "d"], spin: 0.0, mass: 139.57039, isospin: 1.0,  isospin3: -1.0, state: 1, decayTime: 2.6033e-8,  cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "K+",        quarks: ["u", "s"], spin: 0.0, mass: 493.677,   isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 1.2380e-8,  cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "K−",        quarks: ["u", "s"], spin: 0.0, mass: 493.677,   isospin: 0.5,  isospin3: -0.5, state: 1, decayTime: 1.2380e-8,  cp: 0, superposition: 0, charge: -1.0),

    Hadron(name: "Xi0",          quarks: ["u", "s", "s"], spin: 0.5, mass: 1314.860, isospin: 0.5, isospin3: 0.5,state: 1, decayTime: 2.9e-10, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "Lambda0",      quarks: ["u", "d", "s"], spin: 0.5, mass: 1115.683, isospin: 0.0, isospin3: 0, state: 1,   decayTime: 2.631e-10, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "Xi−",          quarks: ["d", "s", "s"], spin: 0.5, mass: 1321.710, isospin: 0.5, isospin3: -0.5,state: 1, decayTime: 1.64e-10, cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Sigma−",       quarks: ["d", "d", "s"], spin: 0.5, mass: 1197.449, isospin: 1.0, isospin3: -1, state: 1,  decayTime: 1.5e-10, cp: 0, superposition: 0, charge: -1.0),

    Hadron(name: "K0_S",      quarks: ["d", "s"], spin: 0.0, mass: 497.611,   isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 8.9598e-11, cp: 1, superposition: 0, charge:  0.0),
    Hadron(name: "Omega−",       quarks: ["s", "s", "s"], spin: 1.5, mass: 1672.450, isospin: 0.0, isospin3: 0, state: 1,   decayTime: 8.2e-11, cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Sigma+",       quarks: ["u", "u", "s"], spin: 0.5, mass: 1189.370, isospin: 1.0, isospin3: 1, state: 1,  decayTime: 8.0e-11, cp: 0, superposition: 0, charge: 1.0),

    Hadron(name: "B+",        quarks: ["b", "u"], spin: 0.0, mass: 5279.1,    isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 1.638e-12,  cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "B−",        quarks: ["b", "u"], spin: 0.0, mass: 5279.1,    isospin: 0.5,  isospin3: -0.5, state: 1, decayTime: 1.638e-12,  cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Xi−b",         quarks: ["d", "s", "b"], spin: 0.5, mass: 5794.400, isospin: 0.5, isospin3: -0.5, state: 1, decayTime: 1.6e-12, cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Xi0b",         quarks: ["u", "s", "b"], spin: 0.5, mass: 5787.800, isospin: 0.5, isospin3: 0.5,state: 1, decayTime: 1.5e-12, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "B0",        quarks: ["b", "d"], spin: 0.0, mass: 5279.1,    isospin: 0.5,  isospin3: -0.5, state: 1, decayTime: 1.5053e-12, cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "B̄0",       quarks: ["b", "d"], spin: 0.0, mass: 5279.1,    isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 1.5053e-12, cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Lambda0b",     quarks: ["u", "d", "b"], spin: 0.5, mass: 5619.600, isospin: 0.0, isospin3: 0, state: 1,   decayTime: 1.409e-12, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "Bs0",       quarks: ["b", "s"], spin: 0.0, mass: 5366.88,   isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 1.360e-12,  cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Bs̄0",      quarks: ["b", "s"], spin: 0.0, mass: 5366.88,   isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 1.360e-12,  cp: 0, superposition: 0, charge:  0.0),
    

    Hadron(name: "Omega−b",      quarks: ["s", "s", "b"], spin: 0.5, mass: 6045.100, isospin: 0.0, isospin3: 0, state: 1,   decayTime: 1.3e-12, cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "D+",        quarks: ["c", "d"], spin: 0.0, mass: 1869.65,   isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 1.040e-12,  cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "D−",        quarks: ["c", "d"], spin: 0.0, mass: 1869.65,   isospin: 0.5,  isospin3: -0.5, state: 1, decayTime: 1.040e-12,  cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Bc+",       quarks: ["b", "c"], spin: 0.0, mass: 6274.9,    isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 5.094e-13,  cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "Bc−",       quarks: ["b", "c"], spin: 0.0, mass: 6274.9,    isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 5.094e-13,  cp: 0, superposition: 0, charge: -1.0),

    Hadron(name: "Ds+",       quarks: ["c", "s"], spin: 0.0, mass: 1968.34,   isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 5.074e-13,  cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "Ds−",       quarks: ["c", "s"], spin: 0.0, mass: 1968.34,   isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 5.074e-13,  cp: 0, superposition: 0, charge: -1.0),

    Hadron(name: "Xi+c",         quarks: ["u", "s", "c"], spin: 0.5, mass: 2468.000, isospin: 0.5, isospin3: 0.5, state: 1, decayTime: 4.4e-13, cp: 0, superposition: 0, charge: 1.0),
    Hadron(name: "D0",        quarks: ["c", "u"], spin: 0.0, mass: 1864.841,  isospin: 0.5,  isospin3: -0.5, state: 1, decayTime: 4.101e-13,  cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "D̄0",       quarks: ["c", "u"], spin: 0.0, mass: 1864.841,  isospin: 0.5,  isospin3:  0.5, state: 1, decayTime: 4.101e-13,  cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Lambda+c",     quarks: ["u", "d", "c"], spin: 0.5, mass: 2286.460, isospin: 0.0, isospin3: 0,  state: 1,  decayTime: 2.0e-13, cp: 0, superposition: 0, charge: 1.0),
    Hadron(name: "Xi0c",         quarks: ["d", "s", "c"], spin: 0.5, mass: 2470.850, isospin: 0.5, isospin3: -0.5, state: 1, decayTime: 1.1e-13, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "Omega0c",      quarks: ["s", "s", "c"], spin: 0.5, mass: 2695.200, isospin: 0.0, isospin3: 0, state: 1,   decayTime: 6.9e-14, cp: 0, superposition: 0, charge: 0.0),



    Hadron(name: "Pi0",       quarks: ["u", "d"], spin: 0.0, mass: 134.9766,  isospin: 1.0,  isospin3:  0.0, state: 1, decayTime: 8.52e-17,    cp: 0, superposition: 1, charge:  0.0),
    Hadron(name: "Eta",       quarks: ["s", "u"], spin: 0.0, mass: 547.862,   isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 5.0e-19,    cp: 0, superposition: 1, charge:  0.0),
    Hadron(name: "Sigma0",       quarks: ["u", "d", "s"], spin: 0.5, mass: 1192.642, isospin: 1.0, isospin3: 0, state: 1,   decayTime: 6.0e-20, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "Upsilon(3S)", quarks: ["b", "b"], spin: 1.0, mass: 10355.2,   isospin: 0.0,  isospin3:  0.0, state: 4, decayTime: 4.2e-20,    cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Upsilon(2S)", quarks: ["b", "b"], spin: 1.0, mass: 10023.26,  isospin: 0.0,  isospin3:  0.0, state: 3, decayTime: 3.9e-20,    cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Psi(2S)",   quarks: ["c", "c"], spin: 1.0, mass: 3686.1,    isospin: 0.0,  isospin3:  0.0, state: 3, decayTime: 2.13e-20,   cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Upsilon(5S)", quarks: ["b", "b"], spin: 1.0, mass: 10885.0,   isospin: 0.0,  isospin3:  0.0, state: 6, decayTime: 1.76e-20,   cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Upsilon(1S)", quarks: ["b", "b"], spin: 1.0, mass: 9460.3,    isospin: 0.0,  isospin3:  0.0, state: 2, decayTime: 1.21e-20,   cp: 0, superposition: 0, charge:  0.0),
    Hadron(name: "Upsilon(4S)", quarks: ["b", "b"], spin: 1.0, mass: 10579.4,   isospin: 0.0,  isospin3:  0.0, state: 5, decayTime: 1.21e-20,   cp: 0, superposition: 0, charge:  0.0),

    Hadron(name: "J/Psi",     quarks: ["c", "c"], spin: 1.0, mass: 3096.9,    isospin: 0.0,  isospin3:  0.0, state: 2, decayTime: 7.2e-21,    cp: 0, superposition: 0, charge:  0.0),

    Hadron(name: "EtaPrime",  quarks: ["u", "s"], spin: 0.0, mass: 957.78,    isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 3.2e-21,    cp: 1, superposition: 1, charge:  0.0),

    Hadron(name: "Sigma++c",     quarks: ["u", "u", "c"], spin: 0.5, mass: 2453.970, isospin: 1.0, isospin3: 1, state: 1,  decayTime: 1.0e-21, cp: 0, superposition: 0, charge: 2.0),
    Hadron(name: "Sigma+c",      quarks: ["u", "d", "c"], spin: 0.5, mass: 2452.900, isospin: 1.0, isospin3: 0, state: 1,   decayTime: 1.0e-21, cp: 0, superposition: 0, charge: 1.0),
    Hadron(name: "Sigma0c",      quarks: ["d", "d", "c"], spin: 0.5, mass: 2453.750, isospin: 1.0, isospin3: -1, state: 1,  decayTime: 1.0e-21, cp: 0, superposition: 0, charge: 0.0),

    Hadron(name: "Phi",       quarks: ["u", "d"], spin: 1.0, mass: 1019.46,   isospin: 0.0,  isospin3:  0.0, state: 1, decayTime: 1.5e-22,    cp: 0, superposition: 1, charge:  0.0),

    Hadron(name: "Delta++",      quarks: ["u", "u", "u"], spin: 1.5, mass: 1232.000, isospin: 1.5, isospin3: 3/2, state: 1, decayTime: 6.0e-24, cp: 0, superposition: 0, charge: 2.0),
    Hadron(name: "Delta+",       quarks: ["u", "u", "d"], spin: 1.5, mass: 1232.000, isospin: 1.5, isospin3: 1/2, state: 1, decayTime: 6.0e-24, cp: 0, superposition: 0, charge: 1.0),
    Hadron(name: "Delta0",       quarks: ["u", "d", "d"], spin: 1.5, mass: 1232.000, isospin: 1.5, isospin3: -1/2, state: 1, decayTime: 6.0e-24, cp: 0, superposition: 0, charge: 0.0),
    Hadron(name: "Delta−",       quarks: ["d", "d", "d"], spin: 1.5, mass: 1232.000, isospin: 1.5, isospin3: -3/2, state: 1, decayTime: 6.0e-24, cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Rho+",      quarks: ["u", "d"], spin: 1.0, mass: 775.11,    isospin: 1.0,  isospin3:  1.0, state: 1, decayTime: 4.5e-24,    cp: 0, superposition: 0, charge:  1.0),
    Hadron(name: "Rho−",      quarks: ["u", "d"], spin: 1.0, mass: 775.11,    isospin: 1.0,  isospin3: -1.0, state: 1, decayTime: 4.5e-24,    cp: 0, superposition: 0, charge: -1.0),
    Hadron(name: "Rho0",      quarks: ["u", "d"], spin: 1.0, mass: 775.11,    isospin: 1.0,  isospin3:  0.0, state: 1, decayTime: 4.4e-24,    cp: 0, superposition: 0, charge:  0.0),

]

struct Hadron {
    let name: String
    let quarks: [String]
    let spin: Double
    let mass: Double
    let isospin: Double
    let isospin3: Double
    let state: Int
    let decayTime: Double
    let cp: Double
    let superposition: Double
    let charge: Double
}

func gate(_ condition: Bool) -> Double { condition ? 1.0 : 0.0 }

// --- Constants ---
let h = 6.582119569e-22

let deltaE: [String: Double] = [
    "u":  2.49296e-25,    // Stabilizing
    "d":  2.49299e-25,    // Weakly destabilizing
    "s":  6.330e-14,      // Strongly destabilizing
    "c":  1.291e-9,       // Rapidly destabilizing
    "b":  4.478e-10,      // Moderately destabilizing
    "t":  1.316e3         // Instantly decaying
]

func deltaEbase(for quarks: [String]) -> Double {
    //Hadron
    var total = 0.0

    for q in quarks {
        switch q {
        case "u":
            total += deltaE["u"]!
        case "d":
            total += deltaE["d"]!
        case "s":
            total += quarks.count == 2 ? deltaE["s"]! : deltaE["s"]! * 1e2
        case "c":
            total += quarks.count == 2 ? deltaE["c"]! : deltaE["c"]! * 16/3
        case "b":
            total += deltaE["b"]!
        case "t":
            total += deltaE["t"]!
        default:
            total += 0
        }
    }

    return total
}

func nQuarks(for quarks: [String]) -> [Double] {
    //Hadron
    var total = 0.0

    //Qu, Qd, Qs, Qc, Qb, Qt
    var Q: [Double] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    for q in quarks {
        switch q {
        case "u":
            Q[0] += 1.0
        case "d":
            Q[1] += 1.0
        case "s":
            Q[2] += 1.0
        case "c":
            Q[3] += 1.0
        case "b":
            Q[4] += 1.0
        case "t":
            Q[5] += 1.0
        default:
            total += 0
        }
    }

    return Q
}





// Full mass prediction function
func predictedDecay(hadron: Hadron) -> Double {

    var output = 1.0
    var state_decay = 1.0

    let NQ = nQuarks(for: hadron.quarks)

    let Nu = NQ[0]
    let Nd = NQ[1]
    let Ns = NQ[2]
    let Nc = NQ[3]
    let Nb = NQ[4]

    //Quark Content
    let Gu = gate(hadron.quarks.contains("u"))
    let Gd = gate(hadron.quarks.contains("d"))
    let Gs = gate(hadron.quarks.contains("s"))
    let Gc = gate(hadron.quarks.contains("c"))
    let Gb = gate(hadron.quarks.contains("b"))

    var G = (Gs == 1.0 || Gc == 1.0) ? 2.0 : 1.0
    G = (Gb == 1.0) ? 3.0 : G

    let G1 = G == 1.0 ? 1.0 : 0.0
    let G2 = G == 2.0 ? 1.0 : 0.0
    let G3 = G == 3.0 ? 1.0 : 0.0

    let Tri = hadron.quarks.count == 3 ? 1.0 : 0.0

    let ΔE = deltaEbase(for: hadron.quarks)

    let N = 1 // Number of Neutron
    let P = 1 // Number of Protons
    let κ = pow(9.83e-11, gate(N != P)) // N / P must == 1

    //Spin Decay
    let s = hadron.spin - abs((2.0 - Double(hadron.quarks.count)) / 2.0)
    let s0 = gate(hadron.spin == 0.0)
    let Spin = [6.55e-27, 4.2575e-9, 6.55e-8,  1.97203e-11]
    var spin_decay = pow(Spin[0] * pow(0.523, abs(Tri-1)) , s * G1) // Phi > Rho0 // Tri - 1 = Rho+ Rho- Rho0
    spin_decay *= pow(Spin[1], s * G2 * abs(Tri-1)) // J/Psi Psi(2)
    spin_decay *= pow(Spin[2], s * G3 * abs(Tri-1)) // All Upsilon
    spin_decay *= pow(Spin[3], s0 * G1 * abs(Tri-1)) //Pi+ Pi-

    //State Decay
    let States = [6.6167, 2.9661, 2.53005e-1, 3.20247, 3.4485, 9.99986e-1, 1.450986]
    state_decay = pow(States[0], Gc * Double(gate(hadron.state >= 2))) // J/Psi Psi(2)
    state_decay *= pow(States[1], Gc * Double(gate(hadron.state == 3))) //Psi(2S)

    state_decay *= pow(States[2], Gb * Double(gate(hadron.state >= 2))) //Upsilon(+1S)
    state_decay *= pow(States[3], Gb * Double(gate(hadron.state == 3))) //Upsilon(2S)
    state_decay *= pow(States[4], Gb * Double(gate(hadron.state == 4))) //Upsilon(3S)
    state_decay *= pow(States[5], Gb * Double(gate(hadron.state == 5))) //Upsilon(4S)
    state_decay *= pow(States[6], Gb * Double(gate(hadron.state == 6))) //Upsilon(5S)

    //Superspin Mixed Decay
    let Superspin = [4.790e-11, 3.093e-13, 3.336e1, 1.74512e-3, 6.74e1]
    var superspin_symmetry_decay = pow(Superspin[0], hadron.superposition * abs(hadron.spin - 1) * abs(hadron.cp - 1)) //Eta
    superspin_symmetry_decay *= pow(Superspin[1], hadron.superposition * abs(hadron.spin - 1) * hadron.cp) // Eta Prime
    superspin_symmetry_decay *= pow(Superspin[2], hadron.superposition * hadron.spin  * abs(hadron.cp - 1)) // Phi
    superspin_symmetry_decay *= pow(Superspin[3], abs(hadron.superposition-1) * abs(hadron.spin - 1) * hadron.cp) // K0_S

    superspin_symmetry_decay *= pow(Superspin[4], hadron.superposition * abs(hadron.spin - 1) * abs(hadron.cp - 1) * Nd) //Pi0

    //Flavor Decay
    var flavor_decay = 1.0
    if Tri == 1 {
        //Baryons Flavor Mixing
        if hadron.isospin == 1.5 {

            let ΔEg1 = 1.04

            flavor_decay *= pow(ΔEg1, 1) // Delta++ Delta+ Delta0 Delta-

        } else if hadron.isospin == 1.0 {

            let ΔEi = 2.066e-9
            let ΔEu = 0.38525
            let ΔEd = 0.725
            let ΔEc = 1.05e-8

            if Ns >= 1 {
                flavor_decay *= pow(ΔEu * ΔEd * ΔEi, gate(Nd * Nu == 1)) // Sigma0
                flavor_decay *= pow(2.0 * ΔEd, gate(Nd == 2)) // Sigma-
                flavor_decay *= pow(2.0 * ΔEu, gate(Nu == 2)) // Sigma+
            } else if Nc == 1 {
                flavor_decay *= pow(ΔEc, 1) // Sigma++c Sigma+c Sigma0c
            }

        } else if hadron.isospin == 0.5 {

            let ΔEi = 2.435
            let ΔEu = 3.99
            let ΔEd = 1.0
            let ΔEs = 1.155
            let ΔEb = 1.07

            if Ns == 2 {
                flavor_decay *= pow(ΔEu * ΔEs / 2 * ΔEi, gate(Nu == 1.0)) //Xi0
                flavor_decay *= pow(ΔEd * ΔEs / 2 * ΔEi * 9/4, gate(Nd == 1.0)) //Xi-
            } else if Ns == 1 {
                if Nc == 1 {
                    flavor_decay *= pow(ΔEu * ΔEs, gate(Nu == 1.0)) // Xi+c
                    flavor_decay *= pow(ΔEd * ΔEs, gate(Nd == 1.0)) //Xi0c
                } else if Nb == 1 {
                    flavor_decay *= pow(ΔEb, 1) //Xi−b Xi0b
                }
            }

        } else if hadron.isospin == 0.0 {

            let ΔEi = 0.246712
            let ΔEj = 7.095
            let ΔEg1 = 5.12744
            let ΔEs = 1.0
            let ΔEc = 0.203806
            let ΔEb = 0.256152

            if Ns == 1.0 {
                flavor_decay *= pow(2.0 * ΔEg1 * ΔEi, gate(Nu * Nd == 1.0)) // Lambda0
            } else if Ns > 1 {
                flavor_decay *= pow(ΔEs / 3.0 * ΔEj, gate(Ns / 3.0 == 1.0)) // Omega−
                flavor_decay *= pow((ΔEb * ΔEs) / 2.0 * ΔEj, gate((Nb * Ns) / 2.0 == 1.0)) // Omega−b
                flavor_decay *= pow((ΔEs * ΔEc) / 2.0 * ΔEj, gate((Ns * Nc) / 2.0 == 1.0)) // Omega0c
            } else if Nc == 1 {
                flavor_decay *= pow(2.0 * ΔEg1 * ΔEc, gate(Nu * Nd * Nc == 1.0)) // Lambda+c
            }
        }

    } else {

        //Meson Flavor Mixing
        let ΔEu = 0.8115
        let ΔEd = 2.0368
        let ΔEs = 1.451
        let ΔEc = 0.986
        let ΔEb = 1.3682

        if hadron.isospin == 0.5 {
            flavor_decay *= pow(ΔEu * ΔEs, gate(Gu * Gs == 1)) // K+ K-
            flavor_decay *= pow(ΔEd * ΔEc, gate(Gd * Gc == 1)) // D+ D-
            flavor_decay *= pow(ΔEu * ΔEb, gate(Gu * Gb == 1)) // B+ B-
            flavor_decay *= pow(ΔEd * ΔEs * 5/3, gate(Gd * Gs == 1)) // K0 K0-
            flavor_decay *= pow(ΔEu * ΔEc, gate(Gu * Gc == 1)) // D0 D0_
        } else if hadron.isospin == 0.0 {
            flavor_decay *= pow(ΔEc * ΔEb, gate(Gc * Gb == 1)) // Bc+ Bc-
            flavor_decay *= pow(ΔEs * ΔEb * 7/15, gate(Gs * Gb == 1)) // Bs0 Bs̄0
        }
    }

    output = κ * (h / ΔE)

    return output * spin_decay * state_decay * superspin_symmetry_decay * flavor_decay
}

// --- Run Predictions ---
var totalError = 0.0

// Data structure for chart points
struct ChartPoint: Identifiable {
    let id = UUID()
    let particle: String
    let type: String  // "Observed" or "Predicted"
    let value: Double
    let index: Int
}

// Generate chart data
var chartPoints: [ChartPoint] = []


for (i, hadron) in hadrons.enumerated() {
    let prediction = predictedDecay(hadron: hadron)
    // Skip invalid values (zero or negative)
    if hadron.decayTime > 0, prediction > 0 {
        chartPoints.append(.init(particle: hadron.name, type: "Observed", value: hadron.decayTime, index: i))
        chartPoints.append(.init(particle: hadron.name, type: "Predicted", value: prediction, index: i))
    }

    let err = ((prediction - hadron.decayTime) / hadron.decayTime) * 100.0
    print("\(hadron.name.padding(toLength: 14, withPad: " ", startingAt: 0)) | Obs: \(hadron.decayTime.description) | Pred: \(prediction.description) | Error: \(err)")
    totalError += abs(err)
}


print(String(format: "Average Δ%% error: %.5f%%", totalError / Double(hadrons.count)))

// SwiftUI Chart View
struct DecayLineChart: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Observed vs Predicted Decay Time")
                .font(.title2).bold()
                .padding(.leading)

            Chart(chartPoints) { point in
                LineMark(
                    x: .value("Index", point.index),
                    y: .value("Decay Time", point.value)
                )
                .foregroundStyle(by: .value("Type", point.type))
                .symbol(by: .value("Type", point.type))
                .interpolationMethod(.catmullRom)
            }
            .chartYScale(type: .log)
            .chartXAxis {
                AxisMarks(values: chartPoints.map { $0.index }) { idx in
                        if let i = idx.as(Int.self),
                           let name = chartPoints.first(where: { $0.index == i })?.particle {
                            AxisValueLabel {
                                Text(name)
                                    .rotationEffect(.degrees(90)) // Rotate label
                                    .frame(width: 80)             // Adjust spacing if needed
                                    .offset(x: -40)
                                    .padding(.vertical, 5.0)
                                    .multilineTextAlignment(.leading)
                            }
                        }
                    }
            }
            .chartYAxis {
                AxisMarks(position: .leading)
            }

            .frame(width:700, height: 300)
            .padding()
        }
        .padding(.all, 20.0)
    }
}

// Render the chart in the playground
PlaygroundPage.current.setLiveView(DecayLineChart())
